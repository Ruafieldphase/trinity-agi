# Task Watchdog Status (2025-11-03T02:03:14.022274+00:00)

- server_url: http://127.0.0.1:8091
- health_ok: True
- queue_size: 0
- results_count: 0
- oldest_task_age_sec: None
- anomalies: none

## recommendations