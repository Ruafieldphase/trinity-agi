# Architecture Artifacts Check
- Time: 2025-11-01T14:39:41
- Summary path: `C:\workspace\agi\outputs\architecture_probe_summary.json`
- Root: `C:\workspace\original_data`
- Found: 6/6 (100.0%)

| File | Root | Exists |
|---|---|---|
| `anomaly_detection.py` | `C:\workspace\original_data` | ✅ |
| `scheduler.py` | `C:\workspace\original_data` | ✅ |
| `lumen_flow_sim.py` | `C:\workspace\original_data` | ✅ |
| `conscious_resonance_map.py` | `C:\workspace\original_data` | ✅ |
| `lumen_realdata_template.py` | `C:\workspace\original_data` | ✅ |
| `lumen_auto_eval.py` | `C:\workspace\original_data` | ✅ |
