﻿# UTF-8 Encoding Conversion Summary (20251101_124815)
Source encoding: euc-kr

-  =>  ( bytes)
-  =>  ( bytes)
-  =>  ( bytes)
-  =>  ( bytes)
-  =>  ( bytes)
-  =>  ( bytes)
-  =>  ( bytes)
-  =>  ( bytes)
-  =>  ( bytes)
