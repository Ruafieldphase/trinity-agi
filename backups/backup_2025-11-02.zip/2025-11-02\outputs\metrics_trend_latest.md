# System Metrics Trend

**Generated**: 2025-11-01 10:40:16
**Duration**: 0.57 hours
**Samples**: 10

## Uptime

| Service | Uptime | Status |
|---------|--------|--------|
| Scheduler | 0% | WARN |
| Queue | 100% | OK |
| OpsManager | 100% | OK |

## Queue Latency
- Avg: 20.4ms
- Min/Max: 9/43ms

## System
- CPU: 34.53%
- Memory: 46.09%


