﻿# UTF-8 Encoding Conversion Summary (20251101_124704)
Source encoding: euc-kr

-  =>  ( bytes)
